#poner el usuario y clave del administrador
#cambiar localhost por la adecuada en caso de haber cambiado la url por defecto

curl -u admin:password "http://localhost:8080/pentaho/plugin/saiku/api/admin/discover/refresh"

curl -u admin:password "http://localhost:8080/pentaho/api/system/refresh/mondrianSchemaCache"

curl -u admin:password "http://localhost:8080/pentaho/plugin/cda/api/clearCache"
