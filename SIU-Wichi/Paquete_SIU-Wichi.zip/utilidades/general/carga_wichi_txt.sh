#!/bin/bash
#
# Script para la carga de datos mediante ETLs de SIU-Wichi
#
# Aporte Gonzalo Pablo Ribera <gribera@ungs.edu.ar>
# Universidad Nacional de General Sarmiento
#
SISTEMAS=(guarani mapuche rhun)

# Paths
PATH_ETL="/usr/local/pentaho/etl"
PATH_KITCHEN="/usr/local/pentaho/data-integration/kitchen.sh"
JOB_GUARANI="carga_de_datos/guarani/principal_carga_guarani.kjb"
JOB_MAPUCHE="carga_de_datos/mapuche/importacion_mapuche.kjb"
JOB_RHUN="carga_de_datos/rhun/importacion_rhun.kjb"

# Base
HOST="localhost"
USUARIO="postgres"
CLAVE="postgres"
BASE="siu_wichi"
PUERTO="5432"

# Uso del script
usoScript () {
  echo -e "Uso del script: \n"
  echo -e "Parámetros obligatorios: \n"
  echo -e "      $0 [SISTEMA] [PATH DATOS] \n"
  echo -e "Parámetros por sistema: \n"
  echo -e "      guarani: [INSTALACION_ID]"
  echo -e "      mapuche: [ACTUALIZACION] [PERIODO (AAAAMM)] [INSTALACION_ID] [OBSERVACIONES]"
  echo -e "      rhun: [ACTUALIZACION] [PERIODO (AAAAMM)] [INSTALACION_ID] [OBSERVACIONES]"
}

actualizacion () {
  ACTUALIZACION=$1
  while [ "$ACTUALIZACION" != 0 ] && [ "$ACTUALIZACION" != 1 ] ; do
    read -p "Parametro 'actualizacion' [0 - Periodo nuevo | 1 - Actualizar periodo ] (obligatorio): " ACTUALIZACION
  done
  eval "ACTUALIZACION=$ACTUALIZACION"
}

periodo () {
  SISTEMA=$1
  PERIODO=$2
  case "$SISTEMA" in
    (mapuche|rhun)
      LEN_PERIODO="6"
      MSK_PERIODO="AAAAMM"
    ;;
  esac
  while [ -z "$PERIODO" ] || ! [[ "$PERIODO" =~ ^[0-9]+$ ]] || [ ${#PERIODO} != "$LEN_PERIODO" ]; do
    read -p "Parametro 'periodo' [$MSK_PERIODO] (obligatorio): " PERIODO
  done
  eval "PERIODO=$PERIODO"
}

instalacionID () {
  INSTALACION_ID=$1
  if [ -z "$INSTALACION_ID" ] ; then
    read -p "Parametro 'instalacion' (obligatorio): " INSTALACION_ID
  fi
  eval "INSTALACION_ID=$INSTALACION_ID"
}

observaciones () {
  OBSERVACIONES=$1
  if [ -z "$OBSERVACIONES" ] ; then
    read -p "Parametro 'observaciones' (opcional): " OBSERVACIONES
  fi
  eval "OBSERVACIONES='$OBSERVACIONES'"
}

# Revisa que el primer parametro sea el sistema el cual se van a cargar los datos
if [ -z "$1" ] ; then
	echo -e "ERROR: Falta indicar el sistema a cargar \n"
	usoScript
	exit
else
  for i in ${SISTEMAS[@]} ; do
    if [ "$i" == "$1" ] ; then
        SISTEMA="$1"
    fi
  done
  if [ -z "$SISTEMA" ] ; then
    echo -e "ERROR: $1 no es un sistema existente para la carga"
    usoScript
    exit
  fi
fi


SALIDA_FILE=$(file -n $2/* | grep ISO-8859 | wc -l)
if [ "$SALIDA_FILE" != 0 ] ; then
  echo -e "ADVERTENCIA: Se encontraron $SALIDA_FILE archivos con condificación ISO-8859"
  while true ; do
    read -n 1 -p "¿Continuar (S/N)? " RESPUESTA
    case $RESPUESTA in
      [Ss]* )
      break;;
      [Nn]* )
        echo -e "\n"
        exit
      break;;
      * )
    esac
  done
fi

PARAMS_BASE="-param=base_usuario=$USUARIO -param=base_clave=$CLAVE -param=base_nombre=$BASE -param=base_host=$HOST -param=base_puerto=$PUERTO -param=rutatxt=$2"

COMANDO="$PATH_KITCHEN"

case "$SISTEMA" in
  (guarani)
    COMANDO="$COMANDO -file=$PATH_ETL/$JOB_GUARANI"
    instalacionID $3
  ;;
  (mapuche)
    COMANDO="$COMANDO -file=$PATH_ETL/$JOB_MAPUCHE"
    actualizacion $3
    periodo $SISTEMA $4
    instalacionID $5
    observaciones $6
  ;;
  (rhun)
    COMANDO="$COMANDO -file=$PATH_ETL/$JOB_RHUN"
    actualizacion $3
    periodo $SISTEMA $4
    instalacionID $5
    observaciones $6
  ;;
esac
COMANDO="$COMANDO $PARAMS_BASE"
if [ -n "$PERIODO" ] ; then
  COMANDO="$COMANDO -param=periodo=$PERIODO"
fi
if [ -n "$ACTUALIZACION" ] ; then
  COMANDO="$COMANDO -param=actualizacion=$ACTUALIZACION"
fi
if [ -n "$INSTALACION_ID" ] ; then
  COMANDO="$COMANDO -param=instalacion=$INSTALACION_ID"
fi
if [ -n "$OBSERVACIONES" ] ; then
  COMANDO="$COMANDO -param='observaciones=$OBSERVACIONES'"
fi

echo -e "\nComando a ejecutar: \n$COMANDO\n"


while true ; do
  read -n 1 -p "¿Ejecutar (S/N)? " RESPUESTA
  case $RESPUESTA in
    [Ss]* )
      echo -e "\nEjecutando ....."
      sh $COMANDO
    break;;
    [Nn]* )
      echo -e "\n"
      exit
    break;;
    * ) echo "";;
  esac
done
